package fr.dauphine.vues;

public interface ConnexionOk {
	
	void connexionOk();

}
