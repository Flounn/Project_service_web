package fr.dauphine.vues;

public interface ListenerDevise {
	
	void changerDevise(boolean withMenu);

}
