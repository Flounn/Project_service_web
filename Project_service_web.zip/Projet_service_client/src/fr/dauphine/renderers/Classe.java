package fr.dauphine.renderers;

public class Classe {
	public final static String Double = "java.lang.Double";
	public final static String Timestamp = "java.sql.Timestamp";
	public final static String Integer = "java.lang.Integer";
	public final static String Time = "java.sql.Time";
	public final static String String = "java.lang.String";
	public final static String ListGenerique = "fr.dauphine.renderers.ListGenerique";
	public final static String ListInteger = "fr.dauphine.renderers.ListInteger";
	public final static String Long = "java.lang.Long";
	public final static String DateSql = "java.sql.Date";
	public final static String Date = "java.util.Date";
	public final static String Boolean = "java.lang.Boolean";
	
}