package fr.dauphine.widgets;

public interface SelectionListener {
	void selectionLigne(long id);

}