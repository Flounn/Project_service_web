package fr.dauphine.widgets;

import fr.dauphine.bibliotheque.LivreService;

public interface SelectionListenerLivre {
	void selectionLigne(LivreService livre);
}
